import os
import asyncio
import telegram
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import yt_dlp
import logging

from database import (
    get_user,
    increment_download_count,
    get_user_language,
    is_admin
)
from utils import get_message, clean_filename, is_nsfw_content, add_watermark_to_video, CONFIG # ✨ تم إضافة الدالتين CONFIG و add_watermark_to_video ✨

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

LOG_CHANNEL_ID = os.getenv("LOG_CHANNEL_ID")
MAX_VIDEO_DURATION = 300
FREE_USER_DOWNLOAD_LIMIT = 5
VIDEO_PATH = 'videos'

if not os.path.exists(VIDEO_PATH):
    os.makedirs(VIDEO_PATH)

async def send_log_to_channel(context: ContextTypes.DEFAULT_TYPE, user: dict, video_info: dict, file_path: str):
    if not LOG_CHANNEL_ID:
        return

    user_id = user.id
    user_name = user.full_name
    username = f"@{user.username}" if user.username else "لا يوجد"
    
    video_title = video_info.get('title', 'N/A')
    video_url = video_info.get('webpage_url', 'N/A')

    # --- ✨ التعديل هنا: استخدام نص عادي بدلاً من الماركدوان ✨ ---
    log_caption = (
        f"✅ تحميل جديد\n\n"
        f"👤 بواسطة: {user_name}\n"
        f"🆔: {user_id}\n"
        f"🔗: {username}\n\n"
        f"🎬: {video_title}\n"
        f"🌐: {video_url}"
    )

    try:
        with open(file_path, 'rb') as video_file:
            await context.bot.send_video(
                chat_id=LOG_CHANNEL_ID,
                video=video_file,
                caption=log_caption
                # لا نستخدم parse_mode هنا
            )
    except Exception as e:
        logger.error(f"❌ فشل إرسال الفيديو إلى قناة السجل: {e}")
        try:
            await context.bot.send_message(
                chat_id=LOG_CHANNEL_ID,
                text=log_caption,
                disable_web_page_preview=True
            )
        except Exception as text_e:
            logger.error(f"❌ فشل إرسال السجل النصي أيضًا: {text_e}")

async def handle_download(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    user_id = user.id
    url = update.message.text
    lang = get_user_language(user_id)
    user_data = get_user(user_id)
    
    if not user_data:
        await update.message.reply_text(get_message(lang, "error_finding_user"))
        return

    is_user_admin = is_admin(user_id)
    is_pro_user = user_data.get("subscription_status") == "pro"

    if not is_user_admin and not is_pro_user and user_data.get('download_count', 0) >= FREE_USER_DOWNLOAD_LIMIT:
        keyboard = [[InlineKeyboardButton(get_message(lang, "subscribe_button_text"), url=get_message(lang, "subscribe_link"))]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(get_message(lang, "limit_reached"), reply_markup=reply_markup)
        return

    # --- ✨ فحص المحتوى الإباحي ✨ ---
    if is_nsfw_content(url):
        await update.message.reply_text(get_message(lang, "nsfw_blocked"))
        return

    processing_message = await update.message.reply_text(get_message(lang, "processing"))
    
    new_filepath = None
    try:
        ydl_opts = {
            'format': 'best[ext=mp4][height<=720]/best[ext=mp4]/best',
            'outtmpl': os.path.join(VIDEO_PATH, '%(title)s.%(ext)s'),
            'noplaylist': True, 'quiet': True, 'merge_output_format': 'mp4',
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            loop = asyncio.get_event_loop()
            info_dict = await loop.run_in_executor(None, lambda: ydl.extract_info(url, download=False))
            
            duration = info_dict.get('duration', 0)
            
            # --- ✨ تطبيق قيود مدة الفيديو (٥ دقائق) للمستخدمين غير المشتركين ✨ ---
            if not is_user_admin and not is_pro_user and duration > MAX_VIDEO_DURATION:
                # إنشاء زر الاشتراك
                keyboard = [[InlineKeyboardButton(get_message(lang, "subscribe_button_text"), url=get_message(lang, "subscribe_link"))]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await processing_message.edit_text(
                    get_message(lang, "duration_limit_exceeded").format(limit=MAX_VIDEO_DURATION // 60), 
                    reply_markup=reply_markup
                )
                return

            await processing_message.edit_text(get_message(lang, "downloading"))
            await loop.run_in_executor(None, lambda: ydl.download([url]))
            
            original_filepath = ydl.prepare_filename(info_dict)
            title = info_dict.get('title', 'video')
            cleaned_title = clean_filename(title)
            new_filepath = os.path.join(VIDEO_PATH, f"{cleaned_title}.mp4")
            
            if os.path.exists(original_filepath):
                if os.path.exists(new_filepath) and original_filepath != new_filepath:
                    os.remove(new_filepath)
                os.rename(original_filepath, new_filepath)
            
            if not os.path.exists(new_filepath):
                raise FileNotFoundError(f"Downloaded video not found at {new_filepath}")

            # --- ✨ تطبيق العلامة المائية ✨ ---
            watermark_enabled = CONFIG.get('premium_features', {}).get('watermark', {}).get('enabled', False)
            
            if watermark_enabled:
                await processing_message.edit_text(get_message(lang, "adding_watermark"))
                
                # إنشاء مسار مؤقت للملف الذي يحتوي على العلامة المائية
                watermarked_filepath = new_filepath.replace('.mp4', '_wm.mp4')
                
                final_filepath = add_watermark_to_video(new_filepath, watermarked_filepath)
                
                # إذا نجحت العملية، نستخدم المسار الجديد، وإلا نستخدم المسار الأصلي
                if final_filepath == watermarked_filepath:
                    os.remove(new_filepath) # حذف الملف الأصلي
                    new_filepath = final_filepath
                # إذا فشلت، final_filepath هو new_filepath الأصلي، ولا نفعل شيئاً.

            await processing_message.edit_text(get_message(lang, "uploading"))
            
            # --- ✨ التصحيح النهائي هنا: استخدام نص عادي ✨ ---
            caption_text = f"{title}\n\nتم التحميل بواسطة @{context.bot.username}"

            with open(new_filepath, 'rb') as video_file:
                await context.bot.send_video(
                    chat_id=update.effective_chat.id, 
                    video=video_file, 
                    caption=caption_text, # لا نستخدم parse_mode
                    reply_to_message_id=update.message.message_id
                )
            
            # --- ✨ التعرف على اسم الفيديو وإعادة توجيهه إلى قناة خاصة ✨ ---
            video_title = info_dict.get('title', 'N/A')
            forward_channel_id = os.getenv("FORWARD_CHANNEL_ID")
            if forward_channel_id:
                try:
                    with open(new_filepath, 'rb') as video_file:
                        await context.bot.send_video(
                            chat_id=forward_channel_id,
                            video=video_file,
                            caption=f"🎬 {video_title}\n\n👤 مستخدم: {user.full_name} ({user.id})"
                        )
                except Exception as e:
                    logger.error(f"❌ فشل إعادة توجيه الفيديو إلى القناة {forward_channel_id}: {e}")

            await send_log_to_channel(context, user, info_dict, new_filepath)
            
            await processing_message.delete()
            
            if not is_user_admin and not is_pro_user:
                increment_download_count(user_id)

    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}", exc_info=True)
        error_message = get_message(lang, "download_failed")
        if isinstance(e, yt_dlp.utils.DownloadError) and "Unsupported URL" in str(e):
            error_message = get_message(lang, "unsupported_platform")
        
        try:
            await processing_message.edit_text(error_message)
        except Exception as edit_error:
            logger.error(f"Failed to edit error message: {edit_error}")
            await update.message.reply_text(error_message)
            
    finally:
        if new_filepath and os.path.exists(new_filepath):
            os.remove(new_filepath)
