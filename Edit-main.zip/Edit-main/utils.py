import json
import os
import re
import logging
from utils_helpers.nsfw_filter import is_nsfw_content
from telegram import BotCommand, BotCommandScopeDefault, BotCommandScopeChat
import ffmpeg # ✨ تم إضافة هذا السطر ✨

# --- إعدادات التسجيل ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- تحميل الرسائل ---
MESSAGES = {}

def load_messages():
    """
    يقوم بتحميل الرسائل من ملف JSON.
    """
    global MESSAGES
    try:
        with open('messages.json', 'r', encoding='utf-8') as f:
            MESSAGES = json.load(f)
        logger.info("✅ تم تحميل ملف الرسائل بنجاح.")
    except FileNotFoundError:
        logger.error("!!! ملف messages.json غير موجود. سيتم استخدام رسائل افتراضية.")
    except json.JSONDecodeError:
        logger.error("!!! خطأ في قراءة ملف messages.json. تأكد من أن تنسيقه صحيح.")

def get_message(lang, key, **kwargs):
    """
    يجلب رسالة مترجمة بناءً على اللغة والمفتاح.
    """
    # افتراضي إلى الإنجليزية إذا كانت اللغة غير موجودة
    if lang not in MESSAGES:
        lang = 'en'
    
    message = MESSAGES.get(lang, {}).get(key, f"_{key}_")
    
    # استبدال المتغيرات إذا وجدت
    if kwargs:
        try:
            message = message.format(**kwargs)
        except KeyError as e:
            logger.warning(f"المتغير {e} مفقود في الرسالة '{key}' للغة '{lang}'")

    return message

async def setup_bot_menu(bot):
    """
    يقوم بإعداد قائمة الأوامر (Menu) للبوت للمستخدمين العاديين والمدراء.
    """
    logger.info("إعداد قائمة أوامر البوت...")
    
    # ... (بقية الدالة setup_bot_menu بدون تغيير)
    
    # الأوامر العامة (باللغة العربية)
    user_commands_ar = [
        BotCommand("start", get_message('ar', 'start_command_desc')),
        BotCommand("account", get_message('ar', 'account_command_desc')),
    ]
    # الأوامر العامة (باللغة الإنجليزية)
    user_commands_en = [
        BotCommand("start", get_message('en', 'start_command_desc')),
        BotCommand("account", get_message('en', 'account_command_desc')),
    ]
    
    # أوامر المدير (باللغة العربية)
    admin_commands_ar = user_commands_ar + [
        BotCommand("admin", get_message('ar', 'admin_command_desc')),
    ]
    # أوامر المدير (باللغة الإنجليزية)
    admin_commands_en = user_commands_en + [
        BotCommand("admin", get_message('en', 'admin_command_desc')),
    ]

    # تعيين الأوامر الافتراضية (للغة الإنجليزية كقاعدة)
    await bot.set_my_commands(user_commands_en)
    logger.info("✅ تم تعيين قائمة الأوامر العامة.")

    # تعيين الأوامر للمدراء
    admin_ids_str = os.getenv("ADMIN_IDS", "").split(',')
    admin_ids = [int(admin_id) for admin_id in admin_ids_str if admin_id]
    
    for admin_id in admin_ids:
        try:
            # نحاول الحصول على لغة المدير وتعيين القائمة المناسبة
            admin_lang = get_user_language(admin_id)
            commands_to_set = admin_commands_ar if admin_lang == 'ar' else admin_commands_en
            await bot.set_my_commands(commands_to_set, scope=BotCommandScopeChat(chat_id=admin_id))
            logger.info(f"✅ تم تعيين قائمة أوامر خاصة للمدير ID: {admin_id}")
        except Exception as e:
            logger.error(f"❌ فشل تعيين أوامر للمدير {admin_id}: {e}")

def clean_filename(filename):
    """
    يزيل الأحرف غير الصالحة من أسماء الملفات.
    """
    return re.sub(r'[\\/*?:"<>|]', "", filename)

def escape_markdown(text: str) -> str:
    """
    يقوم بتهريب الأحرف الخاصة في MarkdownV2.
    """
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', text)

# --- قراءة ملف config.json ---
CONFIG = {}
def load_config():
    """
    يقوم بتحميل الإعدادات من ملف config.json.
    """
    global CONFIG
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            CONFIG = json.load(f)
        logger.info("✅ تم تحميل ملف config.json بنجاح.")
    except FileNotFoundError:
        logger.error("!!! ملف config.json غير موجود.")
    except json.JSONDecodeError:
        logger.error("!!! خطأ في قراءة ملف config.json.")

# --- دالة إضافة العلامة المائية ---
def add_watermark_to_video(input_path: str, output_path: str) -> str:
    """
    يضيف علامة مائية (شعار) شفاف إلى الفيديو باستخدام ffmpeg.
    
    :param input_path: مسار ملف الفيديو الأصلي.
    :param output_path: مسار ملف الفيديو الناتج بعد إضافة العلامة المائية.
    :return: مسار ملف الفيديو الناتج أو مسار الملف الأصلي في حالة الفشل.
    """
    watermark_settings = CONFIG.get('premium_features', {}).get('watermark', {})
    watermark_path = watermark_settings.get('watermark_path')
    position = watermark_settings.get('position', 'bottom_right')

    if not watermark_path or not os.path.exists(watermark_path):
        logger.warning(f"⚠️ مسار العلامة المائية غير صحيح أو غير موجود: {watermark_path}. تجاوز العلامة المائية.")
        return input_path

    # تحديد موضع العلامة المائية
    if position == 'top_left':
        overlay_pos = '10:10'
    elif position == 'top_right':
        overlay_pos = 'W-w-10:10'
    elif position == 'bottom_left':
        overlay_pos = '10:H-h-10'
    else: # bottom_right (الافتراضي)
        overlay_pos = 'W-w-10:H-h-10'

    try:
        # إعداد مسار الإدخال والإخراج
        stream = ffmpeg.input(input_path)
        watermark = ffmpeg.input(watermark_path)

        # فلتر العلامة المائية (مع تغيير حجم الشعار إلى 10% من حجم الفيديو)
        out = (
            ffmpeg
            .filter([stream, watermark], 'overlay', overlay_pos)
            .output(output_path, vcodec='libx264', acodec='copy')
            .overwrite_output()
        )

        # تنفيذ الأمر
        ffmpeg.run(out, quiet=True)
        logger.info(f"✅ تم إضافة العلامة المائية بنجاح إلى: {output_path}")
        return output_path

    except ffmpeg.Error as e:
        logger.error(f"❌ فشل ffmpeg في إضافة العلامة المائية: {e.stderr.decode('utf8')}")
        return input_path
    except Exception as e:
        logger.error(f"❌ خطأ غير متوقع أثناء إضافة العلامة المائية: {e}")
        return input_path

# قم بتحميل الرسائل عند بدء تشغيل الوحدة
load_messages()
load_config()
