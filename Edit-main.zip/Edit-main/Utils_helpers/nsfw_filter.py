import logging
import re
import os

# إعداد التسجيل
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def check_nsfw_url(url: str) -> bool:
    """
    يفحص ما إذا كان الرابط يشير إلى محتوى إباحي باستخدام قائمة سوداء للنطاقات.
    
    :param url: رابط الفيديو.
    :return: True إذا كان الرابط إباحياً، False خلاف ذلك.
    """
    # قائمة سوداء بسيطة (يمكن توسيعها لاحقاً)
    blacklist = [
        "pornhub.com", "xvideos.com", "xnxx.com", "youporn.com", "redtube.com", 
        "tube8.com", "eporner.com", "spankbang.com", "hentai.com"
    ]
    
    for domain in blacklist:
        if domain in url.lower():
            logger.info(f"❌ تم حظر الرابط {url} بسبب وجود النطاق {domain} في القائمة السوداء.")
            return True
            
    return False

def is_nsfw_content(url: str) -> bool:
    """
    الدالة الرئيسية لفحص المحتوى الإباحي.
    """
    return check_nsfw_url(url)
